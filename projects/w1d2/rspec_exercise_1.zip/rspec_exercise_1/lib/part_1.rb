def average(num_1, num_2)
    ( num_1 + num_2 ) / 2.0
end


def average_array(arr)
    1.0 * arr.sum / arr.length 
end


def repeat(str, n)
    str * n 
end


def yell(str)
    str.upcase + "!"
end

def alternating_case(str)
    words = str.split()

    words.map.with_index do |word, i|
            if i.even?
                words[i] = word.upcase
            else
                words[i] = word.downcase
            end
    end
    words.join(" ")
end