def hipsterfy(word)
    vowels = "aeiouAEIOU"
    
    i = word.length - 1
    while i >= 0
        if vowels.include?(word[i])
            return word[0...i] + word[i+1..-1]
        end
        i -= 1
    end

    word
end

def vowel_counts(str)
    vowels = "aeiou"
    hash = Hash.new(0)
    str.downcase.each_char do |ele|
        if vowels.include?(ele)
            hash[ele] += 1
        end
    end
    hash
end

def caesar_cipher(message, n)
    abc = "abcdefghijklmnopqrstuvwxyz"
    result = ""

    message.each_char.with_index do |ele, i|
        if !abc.include?(ele)
            result += ele
        else
            old_index = abc.index(ele)
            new_index = old_index + n
            result += abc[new_index % 26]
        end
    end

    result
end