# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

def largest_prime_factor(n)

    (n).downto(2).each do |factor|
        if is_prime?(factor) && n % factor == 0
            return factor
        end
    end
    
end

def is_prime?(num)

    (2...num).each do |int|
        if num % int == 0
            return false
        end
    end
    true
end

def unique_chars?(str)
    hash = Hash.new(0)
    str.each_char { |char| hash[char] += 1 }

    hash.each do |k , v|
        return false if v > 1
    end
    true
end

def dupe_indices(arr)
    hash = Hash.new(0)

    arr.each_with_index do |ele, i|
        hash[ele] += 1
    end
    results = {}

    hash.each do |k, v|
        if v >= 2
            results[k] = []
        end
    end

    arr.each_with_index do |ele, i|
        if results.has_key?(ele)
            results[ele] = results[ele] << i
        end
    end
    results
end


def ana_array(arr1, arr2)
    
    count1 = Hash.new(0)
    count2 = Hash.new(0)

    arr1.each { |ele| count1[ele] += 1 }
    arr2.each { |ele| count2[ele] += 1 }

    return true if count1 == count2
    
    false
end