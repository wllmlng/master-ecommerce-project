def all_words_capitalized?(arr)
    arr.all? { |word| word == word[0].upcase + word[1..-1].downcase }
end

def no_valid_url?(arr)
    arr.none?{ |url| url[-4..-1] == ".com" || url[-4..-1] ==  ".net" || url[-4..-1] == ".org" || url[-3..-1] == ".io" }
    
end

def any_passing_students?(arr)
    arr.any?{ |student| 1.0 * student[:grades].sum / student[:grades].length >= 75 }
    
end