def select_even_nums(arr)
    arr.select(&:even?)
end

def reject_puppies(arr)
    arr.reject{ |hash| hash["age"] <= 2}
end

def count_positive_subarrays(arr)
    arr.count{ |suba| suba.sum > 0 }
end

def aba_translate(word)
    vowels = "AEIOUaeiou"
    results = ""
    word.each_char.with_index do |ele, i|
        if vowels.include?(ele)
            results += ele + "b" + ele
        else
            results += ele
        end
    end
    results
end


def aba_array(arr)
    arr.map{ |word| aba_translate(word) } 
    
end