class Dog
    def initialize(name, breed, age, bark, favorite_foods)
        @name = name
        @breed = breed
        @age = age
        @bark = bark
        @favorite_foods = favorite_foods
    end

    def name
        @name
    end  

    def breed
        @breed
    end
    
    def age
        @age
    end

    def age=(number)
        @age = number
    end

    def bark
        if @age > 3
            @bark.upcase
        else 
            return @bark.downcase
        end
    end

    def favorite_foods
        @favorite_foods
    end

    def favorite_food?(string)
            @favorite_foods.include?(string.capitalize)
        

        #     if !ele.downcase == str.downcase
        #         return false
        #     end
        # end

        # if !@favorite_foods.include?(str) 
        #     return false
        # end
        # true
    end
end

dog_1 = Dog.new("Fido", "German Shepard", 3, "Bork!", ["Bacon", "Chicken"] )
p dog_1.name

p dog_1.breed

p dog_1.age

p dog_1.age = 10

p dog_1.bark

p dog_1.favorite_foods

p dog_1.favorite_food?("Bacon")