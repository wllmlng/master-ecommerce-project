class Bootcamp
    def initialize(name, slogan, student_capacity)
        @name = name
        @slogan = slogan
        @student_capacity = student_capacity
        @students = []
        @teachers = []
        @grades = Hash.new {|h, k| h[k] = []} #every hash will have [] as defaul
    end
  
    def name
        @name
    end

    def slogan
        @slogan
    end

    def teachers
        @teachers
    end

    def students
        @students
    end

    def hire(str)
        @teachers << str
    end

    def enroll(str)
        if @students.length < @student_capacity
            @students << str
            return true 
        else
            return false
        end
    end

    def enrolled?(string)
        @students.include?(string)
    end

    def student_to_teacher_ratio
        @students.length / @teachers.length
    end

    def add_grade(str, n)
        if enrolled?(str)
            @grades[str] << n
            return true
        else
            return false
        end
    end

    def num_grades(str)
        @grades[str].length

    end

    def average_grade(string)
        if @grades.has_key?(string)
            @grades[string].sum / @grades[string].length
        else
            return nil
        end
    end
end

bootcamp_1 = Bootcamp.new("Map Academy", "Anyone can be a cartographer.", 6)
# p bootcamp_1.name
# p bootcamp_1.slogan
# p bootcamp_1.teachers
# p bootcamp_1.students
# p bootcamp_1.hire("Jeff")
# p bootcamp_1.enroll("Alice")
# p bootcamp_1.students
# p bootcamp_1.enrolled?("Alice")

# p bootcamp_1.hire("Jeff")
# p bootcamp_1.hire("Matthias")
# p bootcamp_1.enroll("student one")
# p bootcamp_1.enroll("student two")        
# p bootcamp_1.enroll("student three")
# p bootcamp_1.enroll("student four")
# p bootcamp_1.student_to_teacher_ratio

# p bootcamp_1.add_grade("Alice", 100)

p bootcamp_1.enroll("Alice")
p bootcamp_1.add_grade("Alice", 100)
p bootcamp_1.add_grade("Alice", 75)
# p bootcamp_1.num_grades("Alice")

p bootcamp_1.average_grade("Alice")
