# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array

  def span
    return nil if self.length == 0
    self.max - self.min
  end

  def average
    return nil if self.length == 0
    average = 1.0 * self.sum / self.length 
    average 
  end

  def median
    return nil if self.length == 0
    sorted = self.sort 
    if sorted.length.odd?
        index = (sorted.length - 1) / 2 
        sorted[index]
    elsif sorted.length.even?
        index = sorted.length / 2 
        (sorted[index] + sorted[index - 1]) / 2.0
    end
  end

  def counts
    hash = Hash.new(0)
    self.each do |char|
      hash[char] += 1
    end
    hash
  end


  def my_count(n)
    count = 0
    self.each{ |ele| count += 1 if ele == n }
    count
  end

  def my_index(ele)
    
    (0...self.length).each do |i|
      if self[i] == ele
        return i
      end
    end
    nil
  end

  def my_uniq
    results = []
    self.each do |ele|
      if !results.include?(ele)
        results << ele
      end
    end
    results
  end

  def my_transpose
    results = []
    current = []
    (0...self.length).each do |i|
      self.each do |sub|
        current << sub[i]
      end
      results << current
      current = []
    end
    results
  end
  



end



