class Board

    # START
    def initialize
        @grid = Array.new(3) { Array.new(3, "_") }
    end

    def valid?(pos)                                                             # Assumption: pos is an Array
        coord_1_valid = ( 0 <= pos[0] && pos[0] < @grid.length )
        coord_2_valid = ( 0 <= pos[1] && pos[1] < @grid.length )
        return coord_1_valid && coord_2_valid
    end

    def empty?(pos)                                                             # Assumption: pos is an Array
        return true if @grid[pos[0]][pos[1]] == "_"
    end

    def place_mark(pos, mark)
        raise "invalid move!" if !self.valid?(pos) || !self.empty?(pos) 
        @grid[pos[0]][pos[1]] = mark if self.valid?(pos) && self.empty?(pos) 
    end

    # CHECKPOINT 1
    def print
       @grid.each do |row|
            puts row 
       end 
    end

    def win_row?(mark)
        return @grid.any?{ |row| row.all?{ |el| el == mark  } }
    end

    def win_col?(mark)
        return @grid.transpose.any?{ |row| row.all?{ |el| el == mark  } }
    end

    def win_diagonal?(mark)
        diag_1 = []
        diag_2 = []
        (0...@grid.length).each do |i|
            diag_1 << @grid[i][i]
            diag_2 << @grid[i][grid.length - 1 - i]
        end
        return diag_1.all? {|el| el == mark } || diag_2.all? {|el| el == mark }
    end

    def win?(mark)
        return win_row?(mark) ||  win_col?(mark) || win_diagonal?(mark)
    end

    def empty_positions?
        @grid.flatten.any? { |ele| ele == "_"  }        
    end

end #end