class Board
    # PART 1
    attr_reader :size

    def initialize(n)
        @grid = Array.new(n) {Array.new(n, :N)}
        @size = n * n
    end

    def [](indices_pair_Arr) # indices_pair_Arr = [0, 1]
        @grid[indices_pair_Arr[0]][indices_pair_Arr[1]]
    end
    
    # Instance Methods
    def []=(pos, val)
        @grid[pos[0]][pos[1]] = val
    end

    # Instane Methods
    def num_ships
        @grid.flatten.count{ |ele| ele == :S }
    end

    # PART 2
    def attack(pos)
        if self[pos] == :S                                                      
           self[pos] = :H
           puts 'you sunk my battleship!'
           return true
        else
           self[pos] = :X
           return false
        end
    end

    def place_random_ships
        # while self.num_ships < ( @size / 4 )
        #     pos = [rand(0...Math.sqrt(@size)), rand(0...Math.sqrt(@size))]
        #     self[pos] = :S
        # end

        while self.num_ships < ( @size / 4 )
            pos = [rand(0...@grid.length), rand(0...@grid.length)]
            self[pos] = :S
        end
    end

    def hidden_ships_grid
        @grid.map do |row|
            row.map do |el|
                if el == :S
                    el = :N 
                else
                    el
                end
            end
        end
    end

    # Class Method
    def self.print_grid(grid)
        grid.each do |row|
            row.each do |el|
                puts row.join(" ")
            end
        end
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(self.hidden_ships_grid)
    end
end #end
