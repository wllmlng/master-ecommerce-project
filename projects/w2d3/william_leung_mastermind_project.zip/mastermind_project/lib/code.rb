class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }
  
  # PART 1
  attr_reader :pegs

  # Class Method
  def self.valid_pegs?(charsArr) # ["R", "G", "G", "G"]
    charsArr.all? { |ele| POSSIBLE_PEGS.has_key?(ele.upcase) }
  end

  # Instance Method
  def initialize(charsArr)
    if Code.valid_pegs?(charsArr)
      @pegs = charsArr.map(&:upcase)    # guess_instance = Code.new(["R", "Y", "Y", "B"]) = ["R", "Y", "Y", "B"]
    else
      raise "invalid characters!"
    end
  end

  # Class Method
  # How to generate array with random elements: Array.new(4) { rand(1...9) }
  # Generate random element from an array: [:foo, :bar].sample # => :foo, or :bar :-)
  def self.random(length)
    Code.new( Array.new(length) { POSSIBLE_PEGS.keys.sample(1) }.flatten )
  end

  # Class Method
  def self.from_string(str)
    Code.new(str.split(""))
  end

  # Instance Method
  def [](idx)
    @pegs[idx]
  end

  # Instance Method
  def length
    @pegs.length
  end

  # PART 2
  def num_exact_matches(guess_instance) # guess_instance = Code.new(["R", "Y", "Y", "B"])
    count = 0
    # Code (Class) Instance Methods Used:
    # (0...guess_instance.length).each do |idx|
    #   if guess_instance[idx] == @pegs[idx]                                      # We can use @pegs b/c @pegs
    #     count += 1                                                              # refers to the @pegs of the instance
    #   end                                                                       # we are calling the method on
    # end

    # code_instance.pegs (Array) using an Array method:
    (guess_instance.pegs).each_with_index do |char, i|
      if char == @pegs[i]
        count += 1
      end
    end

    count
  end
  
  def num_near_matches(guess_instance)
    count = 0

    (guess_instance.pegs).each_with_index do |color, i|
      if @pegs.include?(color) && @pegs[i] != guess_instance.pegs[i]
        count += 1
      end
    end

    count
  end

  def  ==(code_instance)
    code_instance == @pegs # or self.pegs works too
  end
end

