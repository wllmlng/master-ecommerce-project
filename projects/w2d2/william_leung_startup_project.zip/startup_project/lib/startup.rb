require "employee"

class Startup
    attr_accessor :name, :funding, :salaries, :employees

    def initialize(name, funding, salaries)
      @name = name
      @funding = funding
      # salaries (hash) containing `title` => `salary` pairs
      @salaries = salaries
      @employees = []
    end

    def valid_title?(title)
      @salaries.has_key?(title)
    end
    
    # self.funding VS @funding ~ syntactic sugar

    def >(startup)
      self.funding > startup.funding
    end

    def hire(employee_name, title)
      raise "title does not exist" if !self.valid_title?(title)
      @employees << Employee.new(employee_name, title)
    end
    
    def size
      @employees.length
    end

    def pay_employee(employee)
      amount = self.salaries[employee.title]
      raise "not enough funding" if amount > @funding
    
      employee.pay(amount)
      @funding -= amount
    end

    def payday
        @employees.each { |employee| self.pay_employee(employee) }
    end

    def average_salary
        total = 0
        @employees.each do |employee|
            total += @salaries[employee.title]
        end
        total / employees.length
    end

    def close
        @employees = []
        @funding = 0
    end

    def acquire(startup)
        @funding += startup.funding
        startup.salaries.each do |k, v|
            @salaries[k] = v if !@salaries.has_key?(k)
        end
        startup.employees.each do |employee|
            @employees << employee
        end
        startup.close
    end

end