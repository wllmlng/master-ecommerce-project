require_relative "room"

class Hotel
    def initialize(name, hash)
        @name = name
        @rooms = {}

        hash.each do |room_name, capacity|
        @rooms[room_name] = Room.new(capacity)
        end
    end
  
    def name
        @name.split(" ").map {|word| word.capitalize}.join(" ")
    end

    def rooms
        @rooms
    end
    
    def room_exists?(str)
        rooms.has_key?(str)
    end

    def check_in(person, room_name)
        if !room_exists?(room_name)
            print "sorry, room does not exist"
        elsif @rooms[room_name].add_occupant(person)
            print 'check in successful'
        else
            print 'sorry, room is full'
        end
    end

    def has_vacancy?
        @rooms.each do |k , v|
            if !v.full?
                return true
            end
        end
        return false
    end
  
    def list_rooms
        @rooms.each do |k, v|
        puts "#{k} #{v.available_space}"
        end
        
    end
  
end #end of code
