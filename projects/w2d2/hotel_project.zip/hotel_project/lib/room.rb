class Room
    #attr_reader :capacity, :occupants, 
    
    def initialize(capacity)
        @capacity = capacity
        @occupants = Array.new
        
    end

    def capacity
        @capacity
    end

    def occupants
        @occupants
    end

    def full?
        if @occupants.length < capacity
            return false
        elsif @occupants.length == capacity
            return true
        end
         
    end

     def available_space  
            @capacity - @occupants.length
          end


    def add_occupant(str)
        if !self.full? 
            @occupants << str
            return true
        end
        return false
    end








end #ending
