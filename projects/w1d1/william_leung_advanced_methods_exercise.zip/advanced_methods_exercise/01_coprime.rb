# Write a method, coprime?(num_1, num_2), that accepts two numbers as args.
# The method should return true if the only common divisor between the two numbers is 1.
# The method should return false otherwise. For example coprime?(25, 12) is true because
# 1 is the only number that divides both 25 and 12.



def coprime?(num1, num2)
    smaller_n = num1
    if num1 > num2
        smaller_n = num2
    end

    (2...smaller_n).each do |factor|
        if num1 % factor == 0 && num2 % factor == 0
            return false
        end
    end
    return true
end


p coprime?(25, 12)    # => true  1, 5, 25   1, 2, 3, 4, 6, 12
puts
p coprime?(7, 11)     # => true
puts
p coprime?(30, 9)     # => false
puts
p coprime?(6, 24)     # => false
puts