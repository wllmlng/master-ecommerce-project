require "byebug"
def zip(*arrays)
    new_arr = Array.new(arrays[0].length) {Array.new([])}
    arrays.each do |arr|
        arr.each_with_index do |ele, i|
            new_arr[i] << ele
        end
    end
    new_arr
end

#spat [['a', 'b', 'c'] [1, 2, 3]]
# i=0
#sub arr ['a', 'b', 'c'] [1, 2, 3]


def prizz_proc(arr, prc1, prc2)
    result = []

    arr.each do |ele|
        if (prc1.call(ele) && !prc2.call(ele)) || (!prc1.call(ele) && prc2.call(ele))
            result << ele
        end
    end

    result
end

def zany_zip(*arrays)
    sorted = arrays.sort_by { |arr| arr.length }
    new_arr = Array.new(sorted[-1].length) {Array.new([])}
    arrays.each do |arr|
        i = 0
        while i < sorted[-1].length
            new_arr[i] << arr[i]
            i += 1
        end
    end
    new_arr
end


def maximum(arr, &prc)
    return nil if arr.length == 0
    new_arr = arr.map { |ele| prc.call(ele) }
    count = 0
    index = 0
    new_arr.each_with_index do |n, i|
        if n >= count
            count = n
            index = i
        end
    end
    arr[index]
end

def my_group_by(arr, &prc)
    hash = Hash.new { |h,k| h[k] = [] }
    arr.each { |el| hash[prc.call(el)] << el }
    hash
end


def max_tie_breaker(arr, prc, &blc)
    return nil if arr.length == 0
    new_arr = arr.map { |ele| blc.call(ele) }
    count = new_arr.max
    index = new_arr.index(new_arr.max)
    new_arr.each_with_index do |n, i|
        if n == count
            if prc.call(arr[index]) >=  prc.call(arr[i])
                count 
            else
                count = n
                index = i
            end   
        end
    end
    arr[index]
end

def silly_syllables(sent)
    arr = sent.split(' ')
    result = []
    arr.each do |word|
        first = vowel_remove(word)
        last = vowel_remove(first.reverse)
        result << last.reverse
    end
    result.join(' ')
end

def vowel_remove(word)
    vowels = 'aeiouAEIOU'
    front_str = ''
    return word if word.split('').one?{ |el| vowels.include?(el) } || word.split('').none?{ |el| vowels.include?(el) }
    word.each_char.with_index do |letter, i|
        if vowels.include?(letter)
            front_str += word[i..-1]
            break
        end
    end
    front_str
end