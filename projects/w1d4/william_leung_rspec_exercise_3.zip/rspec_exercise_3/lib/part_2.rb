def element_count(arr)
    hash = Hash.new(0)
    arr.each { |pet| hash[pet]+= 1}
    hash
end

def char_replace!(str, h)
    str.each_char.with_index do |char, i|
        if h.has_key?(char)
            str[i] = h[char]
        end
    end
    str
end

def product_inject(arr)
    arr.inject(1) {|acc,el| acc * el}
end


