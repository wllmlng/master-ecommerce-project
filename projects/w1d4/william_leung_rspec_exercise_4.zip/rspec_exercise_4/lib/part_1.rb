def my_reject(arr, &prc)
    arr.select { |num| !prc.call(num) }   
end

def my_one?(arr, &prc)
    solution = []
    arr.each {|ele| solution << ele if prc.call(ele)}
    if solution.length == 1
        return true
    else
        return false
    end
end

def hash_select(h, &prc)
    hash = Hash.new
    h.each do |k, v| 
        if prc.call(k, v) 
            hash[k] = h[k]
        end
    end
    hash
end
# def hash_select(h, &prc)
#     h.select { |k, v| prc.call(k, v) }
# end

def xor_select(arr, prc1, prc2)
    solution = []
    arr.each do |num| 
        if (prc1.call(num) && !prc2.call(num)) || (!prc1.call(num) && prc2.call(num))
            solution << num
        end
    end
    solution
end

def proc_count(num, arr)
    # counter = 0
    # arr.each do |block|
    #     counter += 1 if block.call(num)
    # end
    # counter
    arr.count{ |prc| prc.call(num) }
end

