def proper_factors(num)
    return (1...num).select {|int| num % int == 0}
end

def aliquot_sum(num)
   proper_factors(num).sum
end

def perfect_number?(num)
    aliquot_sum(num) == num
end

def ideal_numbers(n)
    new_arr = []        
    i = 1
    while new_arr.length < n
        i += 1
        new_arr << i if perfect_number?(i)
    end
    return new_arr
end