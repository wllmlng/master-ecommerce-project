# Define your methods here.
def my_map!(arr, &prc)
    (0...arr.length).each do |i|
        arr[i] = prc.call(arr[i])
    end
    arr
end

def two?(arr, &prc)
    results = []
    arr.each do |ele|
        if prc.call(ele)
            results << ele
        end
    end
    results.length == 2 ? true : false
end

def nor_select(arr, prc1, prc2)
    results = []
    arr.each do |ele|
        if !prc1.call(ele) && !prc2.call(ele)
            results << ele
        end
    end
    results
end

def array_of_hash_sum(arr)
    sum = 0
    arr.each do |hash|
        hash.each do |k, v|
            sum += v
        end
    end
    sum
end

def slangify(sent)
    results = []
    arr = sent.split(" ")
    arr.each do |word|
        results << remove(word)
    end
    results.join(" ")
end

def remove(word)
    vowels = "aeiou"
    word.each_char.with_index do |letter, i|
        if vowels.include?(letter)
            return (word[0...i] + word[i+1..-1])
        end
    end
end

def char_counter(str, *letter)
    hash = Hash.new(0)
    if letter.length == 0
        str.each_char do |ele|
            hash[ele] += 1
        end
    end

    str.each_char do |ele|
        if letter.include?(ele)
            hash[ele] += 1
        end        
    end

    letter.each do |char|
        if !hash.has_key?(char)
            hash[char] = 0
        end
     end
    hash
end