# # matrix_addition_reloaded
# def matrix_addition_reloaded(*matrices)
#     result = []
#     matrices.each_with_index do |matrix, i|
#         # p matrix
#         # p matrices[i+1] 
#         n = 0
#         while n < matrix.length
#             # helper function (matrix[n], matrices[i+1][n] )
#             result << sum(matrix[n], matrices[i+1][n])
#             n+=1
#         end
#     end
#     result
# end

# def sum(sub1, sub2)
#     [sub1[0] + sub2[0], sub1[1] + sub2[1]]
# end


            # ______walkers solution------matrix_addition_reloaded
            def matrix_addition_reloaded(*matrices)
                height = matrices.first.length #num of rows
                width = matrices.first[0].length #num of columns
                default_mat = Array.new(height) { Array.new(width, 0)}
                

                matrices.inject(default_mat) do |acc, mat| #acc is a matrix
                    mat_height = mat.length
                    mat_width = mat[0].length
                    return nil if mat_height != height || mat_width != width
                    acc = matrix_addition(acc, mat)
                end  
            end

            def matrix_addition(mat1, mat2)
                height = mat1.length #numb of rows
                width = mat1[0].length #num of columns
                result_mat = Array.new(height) { Array.new(width, nil) }

                (0...height).each do |row_idx|
                    (0...width).each do |col_idx|
                        num1 = mat1[row_idx][col_idx]
                        num2 = mat2[row_idx][col_idx]
                        result_mat[row_idx][col_idx] = num1 + num2
                    end
                end
                result_mat
            end
            #-----------------


matrix_a = [[2,5], [4,7]]
matrix_b = [[9,1], [3,0]]
matrix_c = [[-1,0], [0,-1]]
matrix_d = [[2, -5], [7, 10], [0, 1]]
matrix_e = [[0 , 0], [12, 4], [6,  3]]

# p matrix_addition_reloaded(matrix_a, matrix_b)              # [[11, 6], [7, 7]]
# p matrix_addition_reloaded(matrix_a, matrix_b, matrix_c)    # [[10, 6], [7, 6]]
# p matrix_addition_reloaded(matrix_e)                        # [[0, 0], [12, 4], [6, 3]]
# p matrix_addition_reloaded(matrix_d, matrix_e)              # [[2, -5], [19, 14], [6, 4]]
# p matrix_addition_reloaded(matrix_a, matrix_b, matrix_e)    # nil
# p matrix_addition_reloaded(matrix_d, matrix_e, matrix_c)    # nil


# squarocol?
def method_name
    
end


            # ______walkers solution------squarocol?
                    def squarocol?(grid)
                        grid.each do |row|
                            return true if row.uniq.length == 1
                         end
                        

                        grid.transpose.each do |row|
                            return true if row.uniq.length == 1
                        end
                        false
                     end

            #-------

# p squarocol?([
#     [:a, :x , :d],
#     [:b, :x , :e],
#     [:c, :x , :f],
# ]) # true

# p squarocol?([
#     [:x, :y, :x],
#     [:x, :z, :x],
#     [:o, :o, :o],
# ]) # true

# p squarocol?([
#     [:o, :x , :o],
#     [:x, :o , :x],
#     [:o, :x , :o],
# ]) # false

# p squarocol?([
#     [1, 2, 2, 7],
#     [1, 6, 6, 7],
#     [0, 5, 2, 7],
#     [4, 2, 9, 7],
# ]) # true


# p squarocol?([
#     [1, 2, 2, 7],
#     [1, 6, 6, 0],
#     [0, 5, 2, 7],
#     [4, 2, 9, 7],
# ]) # false




# squaragonal?
def method_name
    
end


            # ______walkers solution------squarocol?
                    def squaragonal?(grid)
                        dimension = grid.length - 1 #3
                        
                        #left diagonal
                        left_diag = []
                        (0..dimension).each do |idx|# 0, 1, 2
                            left_diag << grid[idx][idx]
                        end
                        return true if left_diag.uniq.length == 1
                        #right diagonal
                        right_diag = []
                        (0..dimension).each do |idx|# 0, 1, 2
                            right_diag << grid[idx][dimension - idx ]
                        end
                        return true if right_diag.uniq.length == 1

                        false
                    end


            #-------
p squaragonal?([
    [:x, :y, :o],
    [:x, :x, :x],
    [:o, :o, :x],
]) # true

p squaragonal?([
    [:x, :y, :o],
    [:x, :o, :x],
    [:o, :o, :x],
]) # true

p squaragonal?([
    [1, 2, 2, 7],
    [1, 1, 6, 7],
    [0, 5, 1, 7],
    [4, 2, 9, 1],
]) # true

p squaragonal?([
    [1, 2, 2, 5],
    [1, 6, 5, 0],
    [0, 2, 2, 7],
    [5, 2, 9, 7],
]) # false

# pascals_triangle

# p pascals_triangle(5)
# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1]
# ]

# p pascals_triangle(7)

# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1],
#     [1, 5, 10, 10, 5, 1],
#     [1, 6, 15, 20, 15, 6, 1]
# ]