# anti_prime?
# find # divisors
#create range from 1 to num for each factor
#take module of number and factor if == 0 means divisible then
#shovel array
# check if array.lenth < n


def anti_prime?(num)
    num_count = divisors(num)
    (1...num).each do |factor|
        divisor_count = divisors(factor)
        if num_count < divisor_count
            return false 
        end 
    end  
    true
end

def divisors(num)
    divisors = []
    (1..num).each do |factor|
        if num % factor == 0
            divisors << factor 
        end
    end
    divisors.length
end

# p anti_prime?(24)   # true #1, 2, 3, 4, 6, 8, 12, 24
# p anti_prime?(36)   # true
# p anti_prime?(48)   # true
# p anti_prime?(360)  # true
# p anti_prime?(1260) # true
# p anti_prime?(27)   # false 
# p anti_prime?(5)    # false
# p anti_prime?(100)  # false
# p anti_prime?(136)  # false
# p anti_prime?(1024) # false

# matrix_addition
def matrix_addition(mat1, mat2)
    result = []

    mat2.each_with_index do |sub, i|
        result << [ sub[0] + mat1[i][0], sub[1] + mat1[i][1]]
    end
    result
end

            # ______walkers solution------matrix_addition
            # def matrix_addition(mat1, mat2)
            #     height = mat1.length #numb of rows
            #     width = mat1[0].length #num of columns
            #     result_mat = Array.new(height) { Array.new(width, nil) }

            #     (0...height).each do |row_idx|
            #         (0...width).each do |col_idx|
            #             num1 = mat1[row_idx][col_idx]
            #             num2 = mat2[row_idx][col_idx]
            #             result_mat[row_idx][col_idx] = num1 + num2
            #         end
            #     end
            #     result_mat
            # end


# matrix_a = [[2,5], [4,7]]
# matrix_b = [[9,1], [3,0]]
# matrix_c = [[-1,0], [0,-1]]
# matrix_d = [[2, -5], [7, 10], [0, 1]]
# matrix_e = [[0 , 0], [12, 4], [6,  3]]
# p matrix_addition(matrix_a, matrix_b) # [[11, 6], [7, 7]]
# p matrix_addition(matrix_a, matrix_c) # [[1, 5], [4, 6]]
# p matrix_addition(matrix_b, matrix_c) # [[8, 1], [3, -1]]
# p matrix_addition(matrix_d, matrix_e) # [[2, -5], [19, 14], [6, 4]]


#mutual_factors
def mutual_factors(*nums)
    hash = Hash.new(0)
    nums.each do |num|
        divisors(num).each do |factor|
            if hash.has_key?(factor)
                hash[factor] += 1
            else
                hash[factor] = 1
            end
        end
    end
    
    results = []
    hash.each do |key, value|
        if value == nums.length
            results << key
        end
    end
    results
end

def divisors(num)
    divisors = []
    (1..num).each do |factor|
        if num % factor == 0
            divisors << factor 
        end
    end
    divisors
end


# p mutual_factors(50, 30)            # [1, 2, 5, 10]
# p mutual_factors(50, 30, 45, 105)   # [1, 5]
# p mutual_factors(8, 4)              # [1, 2, 4]
# p mutual_factors(8, 4, 10)          # [1, 2]
# p mutual_factors(12, 24)            # [1, 2, 3, 4, 6, 12]
# p mutual_factors(12, 24, 64)        # [1, 2, 4]
# p mutual_factors(22, 44)            # [1, 2, 11, 22]
# p mutual_factors(22, 44, 11)        # [1, 11]
# p mutual_factors(7)                 # [1, 7]
# p mutual_factors(7, 9)              # [1]


# tribonacci_number
def tribonacci_number(n)
    sequence = [1, 1, 2]

    if n == 1 || n == 2
        return 1
    end

    if n == 3
        return 2
    end
    

    while sequence.length != n
        sequence << (sequence[-1] + sequence[-2] + sequence[-3])
    end
    
    sequence[-1]
end

# p tribonacci_number(1)  # 1
# p tribonacci_number(2)  # 1
# p tribonacci_number(3)  # 2
# p tribonacci_number(4)  # 4
# p tribonacci_number(5)  # 7
# p tribonacci_number(6)  # 13  #[1, 1, 2, 4, 7, 13]
# p tribonacci_number(7)  # 24
# p tribonacci_number(11) # 274

