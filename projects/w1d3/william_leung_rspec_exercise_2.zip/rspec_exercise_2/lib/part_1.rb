def partition(arr, n)
    new_arr1 = [] 
    new_arr2 = []
    
    arr.each { |num| num >= n ? new_arr2 << num : new_arr1 << num }

    [new_arr1, new_arr2]
end

#--------------------------------------------

#create empty hash = {}
#iterate |k , v |through hash2 if hash2key is in hash1 key  ->  add hash 2 to new array : else add hash2 into new hash
#newhash[k] => v to add into new hash
#returns new hash containing both hash key-value UNLESS duplicate
#

def merge(hash1, hash2)
    result = hash2.dup

    hash1.each do | k , v |
        if !result.has_key?(k)
            result[k] = v
        end
    end
    
    result

end


#--------------------------------------------
#split by spaces the sent
#iterate through the sent_arr
#helper method () check the word to see if its in the curse word arr
#replace vowels with * to a str


def censor(sent, arr)
    words = sent.split(" ")
    words_down = words.dup.map { |word| word.downcase }
    cursed_i = []

# Get the indices of the cursed words
    words_down.each_with_index do |ele, i|
        if arr.include?(ele)
            cursed_i << i
        end
    end

    
#Calls to the helper method to censor words
    cursed_i.each do |i|
       words[i] = vowel_rmv(words[i]) 
    end
    words.join(" ")
end

#Censors the word
def vowel_rmv(word)
    censored_wrd = ""
    vowels = "aeiouAEIOU"
    word.each_char do |char|
        if vowels.include?(char)
            censored_wrd += "*"
        else
            censored_wrd += char
        end
    end
    censored_wrd
end

#--------------------------------------------

def power_of_two?(num)

    powers = [1]
   
    (num).times do 
        powers << powers[-1] * 2
    end
 
    powers.include?(num) ? true : false

end