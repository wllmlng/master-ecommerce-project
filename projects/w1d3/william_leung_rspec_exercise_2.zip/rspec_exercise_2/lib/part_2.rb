def palindrome?(str)
    reversed = ""

    (str.length-1).downto(0) { |i| reversed += str[i]}
    str == reversed

end

# desired outcome:
# ["j", "ju", "jum", "jump", "u", "um", "ump", "m", "mp", "p"]


def substrings(str)
    
    new_str = str.split("")
    result = []
    new_str.each.with_index do |ele, i|
        (i...(new_str.length)).each do |num|
            result << (str[i..num])
        end
    end
    result
end



def palindrome_substrings(str)
    result = []
    substrings(str).each do |word|
        if word.length > 1 && palindrome?(word)
            result << word
        end
    end
    result
end